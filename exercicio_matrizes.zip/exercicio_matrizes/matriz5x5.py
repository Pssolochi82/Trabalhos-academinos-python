#Crie uma matriz 5x5 inicializada com zeros e exiba-a no formato de matriz.
matriz = [[0 for _ in range(5)] for _ in range(5)]

for linha in matriz:
    print(linha)

